package com.example.demo.aop3;

public class First {
	public void one(int i) {
		System.out.println("First#one()... i = " + i);
	}
	
	public void two() {
		System.out.println("First#two()...");
	}
}
