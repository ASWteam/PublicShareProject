package com.example.demo.aop7;

import org.springframework.aop.Advisor;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.JdkRegexpMethodPointcut;

public class RegExpExam {

	public static void main(String[] args) {
		First target = new First();
		
		JdkRegexpMethodPointcut pc = new JdkRegexpMethodPointcut();
		
		pc.setPattern(".*hello.*");
		Advisor advisor = new DefaultPointcutAdvisor(pc, 
				new SimpleAdvice());
		
		//Proxy
		ProxyFactory pf = new ProxyFactory();
		pf.setTarget(target);
		pf.addAdvisor(advisor);
		
		First f = (First) pf.getProxy();
		
		f.hello();
		f.hello2();
		f.sayHello();
	}
}
