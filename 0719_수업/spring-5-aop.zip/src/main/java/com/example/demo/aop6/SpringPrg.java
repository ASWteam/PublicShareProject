package com.example.demo.aop6;

import org.aopalliance.aop.Advice;
import org.springframework.aop.Advisor;
import org.springframework.aop.Pointcut;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;

public class SpringPrg {

	public static void main(String[] args) {
		//Create target bean object
		SimpleBean target = new SimpleBean();
		
		//Create the pointcut object
		Pointcut pc = new SimpleDynamicPointcut();
		
		//Create advice, advisor object
		Advice advice = new MySimpleAdvice();
		Advisor advisor = new DefaultPointcutAdvisor(pc, advice);
		
		//Create ProxyFactory
		ProxyFactory pf = new ProxyFactory();
		
		//set the target object
		//Only methods in this object will be filtered
		pf.setTarget(target);
		
		//Add the advisor
		pf.addAdvisor(advisor);
		
		//Get the proxied object
		SimpleBean proxy = (SimpleBean) pf.getProxy();
		
		//Logging will be displayed
		//since x != 100
		proxy.ding(10);
		proxy.ding(101);
		
		//logging will not be displayed
		proxy.ding(100);
	}
}
