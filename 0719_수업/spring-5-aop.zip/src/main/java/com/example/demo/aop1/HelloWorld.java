package com.example.demo.aop1;

public class HelloWorld {
	public void sayHello() {
		System.out.println("AOP!");
		int i = Integer.parseInt("ii");
		System.out.println(i);
//		return "AOP";
	}
}
