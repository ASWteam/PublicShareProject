package com.example.demo.aop3;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class SimpleAdvice implements MethodInterceptor {

	@Override
	public Object invoke(MethodInvocation invocation) throws Throwable {
		System.out.println("--------------Around:Before--------------");
		System.out.println(invocation.getMethod().getName());
		
		Object ret = invocation.proceed();
		
		System.out.println("--------------Around:After:충고가 적용됨--------------");
		
		return ret;
	}

}
