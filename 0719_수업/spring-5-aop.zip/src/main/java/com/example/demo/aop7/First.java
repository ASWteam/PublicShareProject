package com.example.demo.aop7;

public class First {
	public void hello() {
		System.out.println("First#hello() called.");
	}
	
	public void hello2() {
		System.out.println("First#hello2() called.");
	}
	
	public void sayHello() {
		System.out.println("First#sayHello() called.");
	}
}
