package com.example.demo.aop4;

import java.lang.reflect.Method;

import org.springframework.aop.ClassFilter;
import org.springframework.aop.support.DynamicMethodMatcherPointcut;

public class SimpleDynamicPointcut extends DynamicMethodMatcherPointcut {

	// 메소드 이름이 foo 인것이 충고적용 대상
	@Override
	public boolean matches(Method method, Class<?> cls) {
		System.out.println("Static check for " + method.getName());
		return "foo".equals(method.getName());
	}

	// 파라미터 값이 100이 아닐 때 충고 적용
	@Override
	public boolean matches(Method method, Class<?> cls, Object... args) {
		System.out.println("Dynamic check for " + method.getName());

		int i = ((Integer) args[0]).intValue();

		return i != 100;
//		return true;
	}

	// 클래스 이름이 SampleBean.class인것이 충고적용 대상
	public ClassFilter getClassFilter() {
		return new ClassFilter() {

			@Override
			public boolean matches(Class<?> cls) {
				return cls == SampleBean.class;
			}
		};
	}

}
