package com.example.demo.aop2;

import java.lang.reflect.Method;

import org.springframework.aop.support.StaticMethodMatcherPointcut;

public class SimpleStaticPointcut extends StaticMethodMatcherPointcut {

	@Override
	public boolean matches(Method method, Class<?> clazz) {
//		return ("one".equals(method.getName()) && clazz == First.class);
		return ("one".equals(method.getName()) && clazz == First.class);

	}

}
