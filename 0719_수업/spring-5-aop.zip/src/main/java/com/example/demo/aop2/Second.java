package com.example.demo.aop2;

public class Second {
	public void one() {
		System.out.println("Second#one() called");
	}
	
	public void two() {
		System.out.println("Second#two() called");
	}
}
