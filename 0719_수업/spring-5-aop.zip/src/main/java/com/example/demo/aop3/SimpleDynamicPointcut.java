package com.example.demo.aop3;

import java.lang.reflect.Method;

import org.springframework.aop.support.DynamicMethodMatcherPointcut;

public class SimpleDynamicPointcut extends DynamicMethodMatcherPointcut {

	//정적검사
	@Override
	public boolean matches(Method method, Class<?> clazz) {
		System.out.println("static check :: method.getName() :: " + method.getName());
		System.out.println("충고적용에서 제외되었습니다.");
		
//		return clazz == First.class && ("one".equals(method.getName()) && i>10) ;
		return clazz == First.class && "one".equals(method.getName());
	}
	
	//동적검사
	@Override
	public boolean matches(Method method, Class<?> clazz, Object...args) {
		int i = ((Integer) args[0]).intValue();
		
		return i > 10;
	}
	

	
}
