package com.example.demo.aop2;

public class First {
	public void one() {
		System.out.println("First#one() called");
	}
	
	public void two() {
		System.out.println("First#two() called");
	}
}
