package com.example.demo.aop6;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class MySimpleAdvice implements MethodInterceptor {

	private static Log log;
	
	static {
		//create the log object
		log = LogFactory.getLog(MySimpleAdvice.class);
	}
	
	@Override
	public Object invoke(MethodInvocation invocation) throws Throwable {
		
		//print the method call
		String name = invocation.getMethod().getName() 
				+ "(" + invocation.getArguments()[0] + ")";
		
		Object val = null;
		
		if(log.isInfoEnabled()) {
			//log the detail
			log.info("Invoking method " + name);
			
			//call the method
			val = invocation.proceed();
			
			//print method id invoked
			log.info("Method is invoked.");
		}
		
		return val;
		
	}

}
