package com.example.demo.aop4;

import org.springframework.aop.Advisor;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;

public class DynamicPointcutExam {

	public static void main(String[] args) {
		//타겟을 객체로 
		SampleBean target = new SampleBean();
		
		//pointcut 생성
		//advice 생성
		//advisor 생성
		Advisor advisor = new DefaultPointcutAdvisor(
				new SimpleDynamicPointcut(), 
				new SimpleAdvice());
		
		//프록시 생성
		ProxyFactory pf = new ProxyFactory();
		pf.addAdvisor(advisor);
		
		pf.setTarget(target);
		
		//weaving
		SampleBean proxy = (SampleBean) pf.getProxy();
		
		proxy.foo(1);
		proxy.foo(10);
		proxy.foo(100);
		
		proxy.bar();
		proxy.bar();
		proxy.bar();
	
	}
}
