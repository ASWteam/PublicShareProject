package com.example.demo.aop1;

import org.springframework.aop.ThrowsAdvice;

public class ThrowsAdvices implements ThrowsAdvice{
	public void afterThrowing(RuntimeException ex) throws Throwable {
		System.out.println("에러가 발행했습니다.");
	}
}
