package com.example.demo.aop2;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class SimpleAdvice implements MethodInterceptor {

	@Override
	public Object invoke(MethodInvocation invocation) throws Throwable {
		System.out.println(invocation.getMethod().getName());
		
		Object o = invocation.proceed();
		
		System.out.println("SimpleAdvice의 충고 적용완료");
		return o;
	}

}
