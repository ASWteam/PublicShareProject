package com.example.demo.aop6;

public class SimpleBean {
	public void ding(int x) {
		System.out.println("The value is " + x);
	}

}
