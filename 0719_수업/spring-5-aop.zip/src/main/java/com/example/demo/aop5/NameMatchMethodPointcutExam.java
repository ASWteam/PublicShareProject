package com.example.demo.aop5;

import org.springframework.aop.Advisor;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.NameMatchMethodPointcut;

public class NameMatchMethodPointcutExam {

	public static void main(String[] args) {
		First target = new First();
		
		//Advisor
		NameMatchMethodPointcut pc = new NameMatchMethodPointcut();
		pc.addMethodName("one");
		pc.addMethodName("two");
		Advisor advisor = new DefaultPointcutAdvisor(pc, 
				new SimpleAdvice());
		
		//Proxy
		ProxyFactory pf = new ProxyFactory();
		pf.addAdvisor(advisor);
		pf.setTarget(target);
		//weaving
		First proxy = (First) pf.getProxy();
		
		proxy.one();
		proxy.two();
		proxy.three();
		
	}
}
