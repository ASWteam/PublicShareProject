package com.example.demo.aop3;

import java.awt.Point;

import org.aopalliance.aop.Advice;
import org.springframework.aop.Advisor;
import org.springframework.aop.Pointcut;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;

public class DynamicPointcutExam {
	
	public static void main(String[] args) {
		First target = new First();
		
		//Pointcut 생성
		Pointcut pc = new SimpleDynamicPointcut();
		//Advice 생성
		Advice advice = new SimpleAdvice();
		//Advisor 생성
		Advisor advisor = new DefaultPointcutAdvisor(pc, advice);
		
		ProxyFactory pf = new ProxyFactory();
		//타겟지정
		pf.setTarget(target);
		//advisor 지정
		pf.addAdvisor(advisor);
		//proxy weaving
		First proxy = (First) pf.getProxy();
		
		proxy.one(3);
		proxy.one(11);
		proxy.one(20);
		proxy.two();
	}
}
