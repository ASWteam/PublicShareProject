package com.example.demo.aop5;

public class First {
	public void one() {
		System.out.println("First#one...");
	}
	
	public void two() {
		System.out.println("First#two...");
	}
	
	public void three() {
		System.out.println("First#three...");
	}
}
