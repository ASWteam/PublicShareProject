package com.example.demo.aop6;

import java.lang.reflect.Method;

import org.springframework.aop.ClassFilter;
import org.springframework.aop.support.DynamicMethodMatcherPointcut;

public class SimpleDynamicPointcut extends DynamicMethodMatcherPointcut {
	
	//Filter the target class first
	@Override
	public ClassFilter getClassFilter() {
		return new ClassFilter() {
			@Override
			public boolean matches(Class<?> cls) {
				//Only SimpleBean class, not Other classes
				return cls == SimpleBean.class;
			}
		};
	}

	@Override
	public boolean matches(Method method, Class<?> cls, Object... args) {
		
		//Filter the method name, only for ding()
		//advice should be applied
		if(!method.getName().equals("ding")) {
			return false;
		}
		
		//Get the first argument
		int x = (Integer) args[0];
		
		//If x != 100 then it matches, else doesn't
		return x != 100;
	}

}
