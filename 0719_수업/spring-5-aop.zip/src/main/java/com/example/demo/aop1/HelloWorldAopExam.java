package com.example.demo.aop1;

import org.springframework.aop.framework.ProxyFactory;

public class HelloWorldAopExam {
	
	public static void main(String[] args) {
		HelloWorld target = new HelloWorld();
		
		ProxyFactory pf = new ProxyFactory(); //ProxyFactory라는 빈 껍데기를 만듬
		pf.addAdvice(new AroundAdvice()); //어드바이스 추가
		pf.addAdvice(new ThrowsAdvices());
		pf.setTarget(target); //위빙할 타겟 정의
		
		HelloWorld proxy = (HelloWorld) pf.getProxy(); //프록시 생성(weaving위빙)
		proxy.sayHello(); //프록시를 통해 메솟드 호출
		
//		System.out.println(proxy.sayHello()); //결과 : spring은 어렵다
		//리턴값을 바꿔치기할 수 있다.
		
	}
}
