package com.example.proxy4;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class MyAdvice implements MethodInterceptor {

	@Override
	public Object invoke(MethodInvocation invocation) throws Throwable {

		System.out.println("-------Before Advice-------");

		// super.say();
		//invocation : 프록시, 메소드, args가 모두 합쳐진 형태
		//호출할 메소드를 알고 있는??
		//Object: 범용성을 위해서
		Object ret = invocation.proceed();

		System.out.println("=======After Advice=======");

		return ret;
	}

}
