package com.example.proxy4;

import org.aopalliance.aop.Advice;
import org.springframework.aop.framework.ProxyFactory;

public class TestClient {

	public static void main(String[] args) {
		Hello hello = new Hello();
		hello.say(); //항상작 동해야하는 Core concern
		
		System.out.println();
		
//		Hello proxy = new HelloProxy();
//		proxy.say();
		
		//자동으로 만들어지는 기술을 써서 동적으로 ...?
		//소스는 존재하지 않지만 메모리에 객체는 존재함.
		
		Advice advice = new MyAdvice();
		
		ProxyFactory factory = new ProxyFactory();
		factory.setTarget(hello);
		factory.addAdvice(advice);
		//addAdvice()는 Advice자료형을 줘야하는데 MyAdvice()는 MethodInterceptor를 
		//implements하므로 Adive자료형으로 지칭할 수도 있다.
		
		//CGLIB 라이브러리가 제공하는 다이나믹 프록시 기술을 사용하여 동적으로 
		//프록시 객체를 만든다.
		Hello proxy = (Hello) factory.getProxy();
		//proxy 객체는 소스는 존재하지 않지만 메모리에는 존재하기 때문에
		//다이나믹 프록시라고 부른다.
		
		proxy.say();
		
	}
}
