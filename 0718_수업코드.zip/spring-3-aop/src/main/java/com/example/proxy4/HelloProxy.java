package com.example.proxy4;

public class HelloProxy extends Hello{
	
	//자료형이 바뀌지 않아서 Client입장에서 코드가 바뀌지 않는다.
	//그래서 지칭을 어떻게 통일할 것인지가 중요
	//HelloProxy은 Hello를 상속했기 때문에 업캐스팅할수있다.

	@Override
	public void say() {
		System.out.println("-------Before Advice-------");
		
		super.say();
		
		System.out.println("=======After Advice=======");
		
	}
	
}
