package com.example.proxy2;

import java.lang.reflect.Proxy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

public class TestClient {
	
	public static void main(String[] args) {
		
		Hello hello = new HelloImpl();
		hello.say();
		
		System.out.println();
		
		//프록시 객체를 .java 파일을 사용해서 만드는 것이 아니라
		//JDK가 제안하는 다이나믹 프록시 생성기술로 얻는다.
		Hello proxy = (Hello) Proxy.newProxyInstance(
				hello.getClass().getClassLoader(), //클래스 로딩 능력부여
				hello.getClass().getInterfaces(), //위빙할 메소드 목록전달
				new MyAdvice(hello)); //부가로직 전달
		
		proxy.say();
		
		System.out.println("\n\n~~~~~~~~~~\n\n");
		
		System.out.println(hello);
//		com.example.proxy2.HelloImpl@4aa298b7
		
		System.out.println(proxy);
//		----Before Advice----
//		====After Advice====
//		com.example.proxy2.HelloImpl@4aa298b7
		
	}

}
