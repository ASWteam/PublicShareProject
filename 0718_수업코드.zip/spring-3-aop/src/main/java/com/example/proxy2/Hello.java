package com.example.proxy2;

public interface Hello {
	public void say();
	public void say2();
}
