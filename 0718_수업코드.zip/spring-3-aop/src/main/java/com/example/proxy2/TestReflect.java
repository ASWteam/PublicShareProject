package com.example.proxy2;

import java.lang.reflect.Method;

public class TestReflect {

	//Method는 method의 정보를 다룬다.?????
	public static void main(String[] args) {
		Hello hello = new HelloImpl();
		
		Class<? extends Hello> clazz = hello.getClass();
		
		Method[] methods = clazz.getMethods();
		
		for (Method method : methods) {
			System.out.println(method.getName());
		}
	}
}
