package com.example.proxy2;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

//프록시 객체는 java.lang.reflect 패키지 클래스가 제공하는 기술을 사용하여 자동으로 만든다.
//이제 개발자가 해야할 일은 부가로직(어드바이스)를 정의한 메소드를 작성하는 것으로 좁혀졌다.
public class MyAdvice implements InvocationHandler {
	private Object target; 
	//인터페이스의 메소드가 여러개일 때, Proxy는 인터페이스의 모든 메소드를 Override해야한다. 
	//하지만 invoke는 하나의 메소드만 구현하여 재활용할 수 있다.?
	//Method method로 인해서 가능한 일인데 클래스의 메소드 하나만 파라미터로 받는다.
	
	//private Hello hello; 범용성을 위해서 Hello-->Object로 변경
	//범용성: 어드바이스 클래스를 어떠한 타겟 클래스와도 연동해서 사용할 수 있도록
	//슈퍼클래스 Object로 지칭한다.
	
	public MyAdvice(Object target) {
		this.target = target;
	}
	/**
	 * Method method
	 * 어떤 클래스에 메소드라도 취급할 수 있는 능력자!
	 * 한번에 하나의 메소드 정보를 취급한다.
	 */
	@Override //부가로직을 구현
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

		System.out.println("----Before Advice----");

		// 핵심로직을 호출
//		target.say();
		//say()를 알기 위해서는 다운캐스팅을 해야하는데, 문제는
		//어떤 메소드를 부를 것인지가 문제. 

		//범용적으로 어떠한 메소드라도 불러올 수 있는 코드
		Object ret = method.invoke(target, args);
		
		System.out.println("====After Advice====");
		
		return ret;
	}

}
