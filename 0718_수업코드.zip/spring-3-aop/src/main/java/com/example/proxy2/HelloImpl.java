package com.example.proxy2;

//Target
public class HelloImpl implements Hello {

	@Override
	public void say() {
		System.out.println("say() core cencern: 핵심코어");
	}

	@Override
	public void say2() {
		System.out.println("say2() core cencern: 핵심코어");
	}

}
