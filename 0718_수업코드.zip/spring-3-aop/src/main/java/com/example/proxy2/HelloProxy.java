package com.example.proxy2;

/**
 * 현 패키지에는 이 클래스가 필요가 없다.(복습을 위해 남김)
 * JDK Dynamic Proxy 기술을 사용하면
 * 개발자가 더이상 직접 프록시 클래스를 작성할 필요가 없게 된다. 
 *
 */
public class HelloProxy implements Hello {
	private Hello hello; 

	public HelloProxy(Hello hello) {
		this.hello = hello;
	}

	@Override
	public void say() {
		System.out.println("----Before Advice----");
		
		//핵심로직을 호출
		hello.say();
		
		System.out.println("====After Advice====");
	}

	@Override
	public void say2() {
		System.out.println("----Before Advice----");
		
		//핵심로직을 호출
		hello.say2();
		
		System.out.println("====After Advice====");
	}

}
