package com.example.proxy1_1;

//Target
public class HelloImpl implements Hello {

	@Override
	public void say() {
		System.out.println("core cencern: 핵심코어");
	}

}
