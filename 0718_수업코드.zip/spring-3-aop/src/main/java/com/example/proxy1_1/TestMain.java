package com.example.proxy1_1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

//@Component //TestMain을 스프링에 올린다.
public class TestMain {
//	@Autowired //스프링에 있는 HelloImpl, Proxy객체를 가져온다.
	private Hello hello;
	
	public void setHello(Hello hello) {
		this.hello = hello;
	}

	//main()에는 static이므로 따로 메소드를 만들어서 say()를 불러옴
	public void clientUseHello() {
		hello.say();
	}
	
	public static void main(String[] args) {
		
		/*Hello hello = new HelloImpl();
		hello.say();
		
		System.out.println();
		
		Hello proxy = new Proxy(hello);
		//프록시에게 Hello라는 것을 대리하고 있음을 말함.
		
		proxy.say();*/
		
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"hello-config.xml");
		
		TestMain tm = (TestMain) context.getBean("testMain");
		
		tm.hello.say();
	}

}
