package com.example.proxy1_1;

public class Proxy implements Hello {
	private Hello hello; 
	//null이 아니게 생성자나 setter로 받아야 함.(지금은 생성자가 적당)

	public Proxy(Hello hello) {
		this.hello = hello;
	}

	@Override
	public void say() {
		System.out.println("----Before Advice----");
		
		//핵심로직을 호출
		hello.say();
		
		System.out.println("====After Advice====");
	}

}
