package com.example.proxy1_1;

public interface Hello {
	public void say();
}
