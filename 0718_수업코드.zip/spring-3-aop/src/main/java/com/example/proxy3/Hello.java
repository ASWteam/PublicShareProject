package com.example.proxy3;

//Target
public class Hello {
	
	public void say() {
		System.out.println("Core Concern: 핵심로직");
	}

}
