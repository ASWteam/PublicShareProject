package com.example.proxy3;

public class TestClient {

	public static void main(String[] args) {
		Hello hello = new Hello();
		hello.say();
		
		System.out.println();
		
		Hello proxy = new HelloProxy();
		proxy.say();
	}
}
