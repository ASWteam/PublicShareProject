package com.example.proxy1;

//HelloImpl = Target 객체
public class HelloImpl implements Hello {


	@Override
	public void say() {
		/**
		 * 부가로직을 항상 적용하는 것이 아니라 때때로 적용하기도 하고 말아야 하기도 한다면... 
		 * 개발자가 해야 할 조치는 무엇인가?
		 */
		
		System.out.println("Hello AOP!");
		//core concerns: 원래 클래스의 메소드가 제공하는 로직, 항상 서비스하는 로직
		
	}

}
