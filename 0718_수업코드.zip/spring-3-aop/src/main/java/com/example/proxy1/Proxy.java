package com.example.proxy1;

//Proxy
//원래 로직을 제공하는 실체객체가 아니라 실체 흉내를 내는 대리 객체이므로
//항상 제공해야 하는 핵심로직은 실체 객체의 메소드가 처리하도록 연동해야 한다. 
//프록시 객체는 실체 객체를 인지할 필요가 있다.
//(누구 흉내를 내는지 알아야 하는 것)
public class Proxy implements Hello {
	//실체 객체
	private Hello hello;
	// 지금은 생성자를 받거나 new하거나... 지금은 생성자를 받는다.
	
	public Proxy(Hello hello) { //HelloImpl 클래스의 인스턴스
		this.hello = hello;
	}

	@Override
	public void say() {
		System.out.println("------추가한 부가로직:Before Advice------");
		//타겟 객체를 호출하는 로직 이외의 부가로직을 Advice라고 한다.
		
		hello.say();
		//타겟 객체의 핵심로직을 호출
		
		System.out.println("======추가한 부가로직:After Advice======");
	}
	
}
