package com.example.proxy1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

@Component //1. 스프링이 관리하고
public class TestMain { //Client

	//타겟객체를 사용하는 고객 객체 입장에서 
	//고객 객체는 자신이 사용할 객체를 스프링으로부터 DI받아서 사용한다.
	//이때, 스프링이...
	//1. 타겟객체를 주입한다.
	//2. 프록시 객체를 주입한다.
	//위 두가지 방법 중에 어떤 것을 선택할지 개발자가 선언적으로 스프링에게 요청한다. 
	//중요! 고객 객체는 인터페이스로 업캐스팅해서 객체의 자료형을 지칭하므로
	//자신이 사용하는 객체가 타겟 객체인지 프록시 객체인지 코드레벨에서 알지 못한다.
	//일지 못해야 한다. 그래야 수정이 없다.
//	@Autowired //2. 스프링이 준다.(DI했을 때 스프링이 객체를 준다)
//	private Hello hello;
	//HelloImpl과 Proxy는 모두 interface인 Hello를 구현했기 때문에, 환경설정으로 조작이 가능하다.
	
	public static void main(String[] args) {
//		Hello hello = new HelloImpl(); @comoponent와 @Autowired로 생성자를 만들지 않아도 된다.
		
//		System.out.println("------추가한 부가로직------");
//		hello.say(); //원래 제공하는 로직 
//		System.out.println("======추가한 부가로직======");
		//추가한 부가로직은 say()에 있어야한다. 
		//단일책임원칙에 위반되는 형태이기 때문이다. 
		//Refactoring을 한다. 
		
//		hello.say(); //원래 제공하는 로직
		
//		ApplicationContext context = new ClassPathXmlApplicationContext(
//				"proxy-config.xml");
//		TestMain testMain = (TestMain) context.getBean("testMain");
//		testMain.hello.say();
		
		Hello hello = new HelloImpl();
		//타겟 객체의 메소드를 호출
		hello.say();
		
		System.out.println("\n");
		
		Hello hello2 = new Proxy(hello);
		//프록시 객체의 메소드를 호출 ==>타겟 객체의 메소드를 호출(즉, 거쳐간다)
		hello2.say();
	}

}
