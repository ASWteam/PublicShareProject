package com.example.proxy1;

public interface Hello {
	public void say();
}
