package com.example.demo.aopns3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {

	public static void main(String[] args) {
//		ApplicationContext context = new ClassPathXmlApplicationContext(
//				"aop-ns-config3.xml");
		
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"aop-ns-config4.xml");
		
		One one = (One) context.getBean("one");
		one.name();
		one.name2();
		one.id();
		one.add(2, 4);
		
		Two two = (Two) context.getBean("two");
		two.name();
		two.name2();
		two.id();
		two.add(2,5);
	}
}
