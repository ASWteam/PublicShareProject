package com.example.demo.aspectj;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

//MethodInterceptor : 
public class SimpleAdvice implements MethodInterceptor {

	@Override
	public Object invoke(MethodInvocation invocation) throws Throwable {
		System.out.println("------------Before-------------");
		System.out.println(invocation.getMethod().getName());
		System.out.println("------------Before-------------");
		
		Object o = invocation.proceed();
		
		System.out.println("==========After===========");
		System.out.println("... SimpleAdvice 의 충고가 적용됨...");
		System.out.println("==========After===========");
		return o;
	}

}
