package com.example.demo.statics;

import java.lang.reflect.Method;

import org.springframework.aop.support.StaticMethodMatcherPointcut;

public class MyStaticMethodMatcherPointcut extends StaticMethodMatcherPointcut {

	@Override
	public boolean matches(Method method, Class<?> clazz) {
		//어드바이스 적용 대산 선택 전략
		//객체는 First.class 인스턴스 이어야 한다. 
		//메소드 명은 "one"이어야 한다.
//		return clazz == First.class && method.getName().equals("one");
		
		//실습
		//대상 선택전략을 다음으로 교체하시오.
		
		//1. Second 클래스에서 메소드명이 one으로 시작하지 않는 메소드에만 어드바이스를 적용한다.
//		return clazz == Second.class && !method.getName().equals("one");
		
		//2. 메소드명이 2으로 끝나는 메소드에만 어드바이스를 적용한다.
		return clazz == Second.class && method.getName().endsWith("2");
		
		//3. First, Second 클래스에서 파라미터를 받는 메소드에만 어드바이스를 적용한다.
		
		
	}

}
