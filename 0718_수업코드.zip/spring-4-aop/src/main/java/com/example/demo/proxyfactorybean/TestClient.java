package com.example.demo.proxyfactorybean;

import org.aopalliance.aop.Advice;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClient {

	public static void main(String[] args) {
//		Hello hello = new Hello();
//		hello.say();
//
//		System.out.println();
//
//		Advice advice = new MyAdvice();
//
//		ProxyFactory factory = new ProxyFactory();
//		factory.setTarget(hello);
//		factory.addAdvice(advice);
//
//		Hello proxy = (Hello) factory.getProxy();
//		proxy.say();

		//설정을 통해 스프링에게 프록시 객체를 주입하라고 요청한다.
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"proxy-factory-bean-config.xml");
		
		Hello hello = (Hello) context.getBean("hello");
		hello.say();
		
		Hello proxy = (Hello) context.getBean("proxy");
		proxy.say();
		
	}
}
