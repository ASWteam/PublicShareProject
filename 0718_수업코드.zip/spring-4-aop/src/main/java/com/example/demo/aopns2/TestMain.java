package com.example.demo.aopns2;

import org.aopalliance.aop.Advice;
import org.springframework.aop.Advisor;
import org.springframework.aop.Pointcut;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.demo.statics.MyStaticMethodMatcherPointcut;

public class TestMain {

	public static void main(String[] args) {
//		First f = new First();
//		Second s = new Second();
//		
//		First proxyFirst;
//		Second proxySecond;
//		
//		AspectJExpressionPointcut pc = new AspectJExpressionPointcut();
//		/**
//		 * execution() : 사용하는 표현식 종류 표기
//		 * * two*(..) : 접근제어자 메소드명(파라미터정의)
//		 * ------------------------------
//		 * * : 접근제어자는 무엇이든지 괜찮음
//		 * two* : 메소드명이 two로 시작해야 함
//		 * (..) : 파라미터 개수와 자료형은 무엇이든지 괜찮음
//		 */
//		pc.setExpression("execution(* two*(..))");
//		
//		Advice advice = new SimpleAdvice();
//		
//		// 어드바이스, 포인트컷을 모두 취급하는 객체
//		Advisor advisor = new DefaultPointcutAdvisor(pc, advice);
//		
//		// First 프록시 생성
//		ProxyFactory pf = new ProxyFactory();
//		pf.addAdvisor(advisor);
//		pf.setTarget(f); // First.class를 타겟으로
//		
//		proxyFirst = (First) pf.getProxy();
//		proxyFirst.one();
//		proxyFirst.two();
//		proxyFirst.two2();
//		proxyFirst.add(2, 3);
//		
//		System.out.println("\n");
//		
//		// Second 프록시 생성
//		pf = new ProxyFactory();
//		pf.addAdvisor(advisor);
//		pf.setTarget(s); // Second.class를 타겟으로
//		
//		proxySecond = (Second) pf.getProxy();
//		proxySecond.one();
//		proxySecond.two();
//		proxySecond.two2();
//		proxySecond.add(2, 3);
		
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"aop-ns-config2.xml");
		
		// 타겟 객체를 빈 컨테이너에 등록한다.
		
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		String[] names = context.getBeanDefinitionNames();
		for (int i = 0; i < names.length; i++) {
			System.out.println((i+1)+" : "+names[i]);
		}
		
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		
		// AOP 네임스페이스 전역설정을 참조한다.
		// DI 해달라고 요청 받은 객체가 AOP 전역설정에 해당하는 객체면
		// 타겟 객체를 주는 대신 이 때 다이나믹하게 프록시 객체를 만들어서 대신 
		// 프록시 객체를 주입한다.
		
		First first = (First) context.getBean("first");
		first.one();
		first.two();
		first.two2();
		first.add(2, 3);
		
		Second second = (Second) context.getBean("second");
		second.one();
		second.two();
		second.two2();
		second.add(2, 3);
		
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		String[] ns = context.getBeanDefinitionNames();
		for (int i = 0; i < ns.length; i++) {
			System.out.println((i+1)+" : "+ns[i]);
		}
		
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}

}
