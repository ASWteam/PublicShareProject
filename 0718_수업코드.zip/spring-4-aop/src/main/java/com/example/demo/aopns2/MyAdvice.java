package com.example.demo.aopns2;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.stereotype.Component;

@Component("myAdvice")
public class MyAdvice 
//implements MethodInterceptor 
{

//	@Override
//	public Object invoke(MethodInvocation invocation) throws Throwable {
//		System.out.println("----------------Before-----------------");
//		System.out.println(invocation.getMethod().getName());
//		System.out.println("----------------Before-----------------");
//
//		Object o = invocation.proceed();
//
//		System.out.println("================After =================");
//		System.out.println("... SimpleAdvice의 충고가 적용됨 ...");
//		System.out.println("================After =================");
//
//		return o;
//	}

	public void myBefore() {
		System.out.println("-------Before-------");
	}

	public Object myAround(ProceedingJoinPoint joinPoint) throws Throwable {
		System.out.println("-------Around:Before-------");
		
		// 타겟 메소드 호출
		Object ret = joinPoint.proceed();
		
		System.out.println("=======Around: After=======");
		
		return ret;
	}
	
	public void myAfterReturning() { 
		System.out.println("=======AfterReturning=======");
	}

	public void myAfterThrowing() {
		System.out.println("=======AfterThrowing=======");
	}

	public void myAfter() {
		System.out.println("=======After(finally)=======");
	}
}
