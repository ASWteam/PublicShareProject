package com.example.demo.aopns3;

import org.springframework.stereotype.Component;

@Component
public class Two {
	public void name() {
		System.out.println("Two#name() call");
	}
	public void name2() {
		System.out.println("Two#name2() call");
	}
	public void id() {
		System.out.println("Two#id() call");
	}
	public int add(int...args) {
		System.out.println("Two#add(int...args) called");
		int sum = 0;
		for (int i : args) {
			sum += i;
		}
		return sum;
	}
}
