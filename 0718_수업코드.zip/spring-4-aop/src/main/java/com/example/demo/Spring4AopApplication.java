package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring4AopApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring4AopApplication.class, args);
	}
}
