package com.example.demo.statics;

public class Second {
	public void one() {
		System.out.println("Second#One() called.");
		//# : 참조한다.
	}

	public void two() {
		System.out.println("Second#two() called.");
	}
	
	public void two2() {
		System.out.println("Second#two2() called.");
	}
	
	public int add(int...args) {
		System.out.println("Second#add(int...args) called.");
		
		int sum = 0;
		for (int i : args) {
			sum += i;
		}
		return sum;
	}
}
