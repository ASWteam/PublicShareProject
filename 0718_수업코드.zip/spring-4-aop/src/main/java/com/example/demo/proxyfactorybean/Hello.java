package com.example.demo.proxyfactorybean;

//Target
public class Hello {
	
	public void say() {
		System.out.println("Core Concern: 핵심로직");
	}
	
	

}
