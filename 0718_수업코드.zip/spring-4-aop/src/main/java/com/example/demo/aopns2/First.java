package com.example.demo.aopns2;

import org.springframework.stereotype.Component;

@Component
public class First {
	
	public void one(){
		System.out.println("First#one() called");
	}
	
	public void two(){
		System.out.println("First#two() called");
	}
	
	public void two2(){
		System.out.println("First#two2() called");
	}
	
	public int add(int...args){
		System.out.println("First#add(int...args) called");
		int sum = 0;
		for (int i : args) {
			sum += i;
		}
		return sum;
	}
}
