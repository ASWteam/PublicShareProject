package com.example.demo.aopns3;

import org.springframework.stereotype.Component;

@Component
public class One {
	public void name() {
		System.out.println("One#name() call");
	}
	public void name2() {
		System.out.println("One#name2() call");
	}
	public void id() {
		System.out.println("One#id() call");
	}
	public int add(int...args) {
		System.out.println("One#add(int...args) called");
		int sum = 0;
		for (int i : args) {
			sum += i;
		}
		return sum;
	}
}
