package com.example.demo.aspectj;

import org.aopalliance.aop.Advice;
import org.springframework.aop.Advisor;
import org.springframework.aop.Pointcut;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;

public class TestMain {

	public static void main(String[] args) {
		First f = new First();
		Second s = new Second();
		
		First proxyFirst;
		Second proxySecond;
		
		AspectJExpressionPointcut pc = new AspectJExpressionPointcut();
		
		/**
		 * execution() : 사용하는 표현식 종류 표기
		 * * two*(..) : 접근제어자 메소드명(파라미터정의)
		 * ----------------------------------------------
		 *  *	: 접근제어자는 무엇이든지 괜찮음
		 * two* : 메소드명이 two로 시작해야 함
		 * (..) : 파라미터 개수와 자료형은 무엇이든지 괜찮음
		 */
		pc.setExpression("execution(* two*(..))");
		
		Advice advice = new SimpleAdvice();
		
		//Advisor(자료형) : 어드바이스, 포인트컷을 모두 취급하는 객체
		//어떤 어드바이스(advice)를 누구(pc)에게 적용할 것이냐?
		Advisor advisor = new DefaultPointcutAdvisor(pc, advice);
		
		// First 프록시 생성
		ProxyFactory pf = new ProxyFactory();
		pf.addAdvisor(advisor);
		pf.setTarget(f); // First.class를 타겟으로
		
		proxyFirst = (First) pf.getProxy(); 
		proxyFirst.one();
		proxyFirst.two();
		proxyFirst.two2();
		proxyFirst.add(2, 3);
		
		// Second 프록시 생성
		pf = new ProxyFactory();
		pf.addAdvisor(advisor);
		pf.setTarget(s); // Second.class를 타겟으로
		
		proxySecond = (Second) pf.getProxy();
		proxySecond.one();
		proxySecond.two();
		proxySecond.two2();
		proxySecond.add(2, 3);

	}

}
