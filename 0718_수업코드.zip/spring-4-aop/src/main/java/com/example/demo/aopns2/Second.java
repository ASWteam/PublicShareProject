package com.example.demo.aopns2;

import org.springframework.stereotype.Component;

@Component
public class Second {
	
	public void one(){
		System.out.println("Second#one() called");
	}
	
	public void two(){
		System.out.println("Second#two() called");
	}
	
	public void two2(){
		System.out.println("Second#two2() called");
	}
	
	public int add(int...args){
		System.out.println("Second#add(int...args) called");
		int sum = 0;
		for (int i : args) {
			sum += i;
		}
		return sum;
	}
}
