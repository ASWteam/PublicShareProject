package onj.hello.aop.mart;

import org.springframework.aop.ThrowsAdvice;

public class ThrowsLoggingAdvice implements ThrowsAdvice {
	//예외를 던질 때 호출
	public void afterThrowing(Throwable throwable) {
		System.out.println("에러발생!!!");
	}
}
