package onj.hello.aop.mart;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class AroundLoggingAdvice implements MethodInterceptor {
	//메소드 호출 전/후 실행

	@Override
	public Object invoke(MethodInvocation invocation) throws Throwable {
		String findName = (String) invocation.getArguments()[0];
		String methodName = invocation.getMethod().getName();
		
		System.out.println("[주변충고]" + methodName + "(" + findName + ")::메소드 실행전----Around:Before");
		Object obj = invocation.proceed();
		System.out.println("[주변충고]" + methodName + "(" + findName + ")::메소드 실행후====Around:After");
		
		return obj;
	}

}
