package onj.hello.aop.mart;

public class SmallMart implements MartInterface {

	@Override
	public void getProducts(String productName) throws Exception {
		System.out.println("[Target Method]getProducts() : " + productName);
//		throw new Exception("error");
	}

	@Override
	public void getProducts2(String productName) throws Exception {
		System.out.println("[Target Method]getProducts2() : " + productName);		
	}

}
