package onj.hello.aop.mart;

public class BigMart implements MartInterface {
	//교재에는 없지만 한번 해보자
	//두개의 클래스를 proxy화 하기
	@Override
	public void getProducts(String productName) throws Exception {
		System.out.println("[Target Method]getProducts() : " + productName);
	}

	@Override
	public void getProducts2(String productName) throws Exception {
		System.out.println("[Target Method]getProducts2() : " + productName);		
	}
}
