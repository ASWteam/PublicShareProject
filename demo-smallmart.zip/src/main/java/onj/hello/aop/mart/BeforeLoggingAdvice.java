package onj.hello.aop.mart;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

public class BeforeLoggingAdvice implements MethodBeforeAdvice {
	//메소드 실행 전에 전처리 기능

	@Override
	public void before(Method method, Object[] args, Object target) throws Throwable {
		String findName = (String) args[0];
		System.out.println(method.getName() + "(" + findName + "):: 사전 충고-----------------Before");
		
	}
	
}
