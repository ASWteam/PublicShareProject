package onj.hello.aop.mart;

import org.aopalliance.aop.Advice;
import org.springframework.aop.Advisor;
import org.springframework.aop.Pointcut;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSmallmartApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(DemoSmallmartApplication.class, args);
		
		MartInterface target = new SmallMart();
		
		ProxyFactory pf = new ProxyFactory();
		
		//pointcut 생성
		Pointcut pc = new SmallmartStaticPointcut();
		Advice advice = new AroundLoggingAdvice();
		Advisor advisor = new DefaultPointcutAdvisor(pc, advice);
		pf.addAdvisor(advisor);
		
		advice = new BeforeLoggingAdvice();
		advisor = new DefaultPointcutAdvisor(pc, advice);
		pf.addAdvisor(advisor);
		
		advice = new AfterLoggingAdvice();
		advisor = new DefaultPointcutAdvisor(pc, advice);
		pf.addAdvisor(advisor);
		
		advice = new ThrowsLoggingAdvice();
		advisor = new DefaultPointcutAdvisor(pc, advice);
		pf.addAdvisor(advisor);
		
		pf.setTarget(target);
		
		try {
			MartInterface proxy = (MartInterface) pf.getProxy(); //weaving
			
			proxy.getProducts("노트북");
			proxy.getProducts2("키보드");
			
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
		
	}
}
