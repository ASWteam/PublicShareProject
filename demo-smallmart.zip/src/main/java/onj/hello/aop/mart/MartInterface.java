package onj.hello.aop.mart;

public interface MartInterface {
	//이전에 작성한 SmallMart 예제에서 getProducts2() 메소드를 적당히 만들고 
	//getProducts2() 메소드에만 충고가  내려갈 수 있도록 재작성 부탁드립니다.
	public void getProducts(String productName) throws Exception;
	public void getProducts2(String productName) throws Exception;
}
