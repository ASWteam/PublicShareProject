package com.example.demo.jdbc.repository;

import java.util.List;

import com.example.demo.jdbc.domain.Emp;

public interface EmpRepository {
	public List<Emp> findAll();
	public Emp findOne(Long empno);
	public Emp save(Emp emp);
	public void delete(Long empno);
}
