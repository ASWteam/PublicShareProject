package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jdbc4Application {

	public static void main(String[] args) {
		SpringApplication.run(Jdbc4Application.class, args);
	}
}
