package com.javatpoint;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");

		EmployeeDao dao = (EmployeeDao) ctx.getBean("edao");

		List<Employee> employees = dao.findAll();
		int i = 1;
		for (Employee e : employees) {
			System.out.print(i++ + ". ");
			System.out.println(e);
		}

		System.out.println("----------selectAll----------");

		dao.saveEmployee(new Employee(111,"sonoo",15000));
		employees = dao.findAll();
		i = 1;
		for (Employee e : employees) {
			System.out.print(i++ + ". ");
			System.out.println(e);
		}
		System.out.println("----------insert----------");
		
		Employee employee = dao.findOne(new Employee(1));
		System.out.println(employee);
		System.out.println("----------selectById----------");
	}
}
