package com.javatpoint;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class EmployeeRowMapper implements RowMapper{
	
	@Override
	public Object mapRow(ResultSet rs, int arg1) throws SQLException {
		int id = rs.getInt("id");
		String name = rs.getString("name");
		float salary = rs.getFloat("salary");
		
		return new Employee(id, name, salary);
	}

}
