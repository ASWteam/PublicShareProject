package com.javatpoint;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class EmployeeDao {
	private JdbcTemplate jdbcTemplate;
	
	RowMapper<Employee> employeeRowMapper;
	
	public void setEmployeeRowMapper(RowMapper<Employee> employeeRowMapper) {
		this.employeeRowMapper = employeeRowMapper;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int saveEmployee(Employee e) {
		String query = 
			"insert into employee values('"+e.getId()+"','"+e.getName()+"','"+e.getSalary()+"')";
		return jdbcTemplate.update(query);
	}
	
	public int updateEmployee(Employee e) {
		String query = "update employee set name='"+e.getName()+"',salary='"+e.getSalary()+"'where id='"+e.getId()+"'";
		return jdbcTemplate.update(query);
	}
	
	public int deleteEmployee(Employee e) {
		String query = "delete from employee where id='"+e.getId()+"'";
		return jdbcTemplate.update(query);
	}
	
	public List<Employee> findAll() {
		String query = "select * from employee";
		List<Employee> employees = jdbcTemplate.query(query, employeeRowMapper);
		return employees;
	}
	
	public Employee findOne(Employee e) {
		String query = "select * from employee where id= '"+e.getId()+"'";
		Employee employee = jdbcTemplate.queryForObject(query, employeeRowMapper);
		return employee;
	}
}
