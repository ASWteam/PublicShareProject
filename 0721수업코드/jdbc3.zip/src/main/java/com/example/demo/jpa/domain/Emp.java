package com.example.demo.jpa.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Emp {

	@Id
	@GeneratedValue
	private Long empno;
	@Column
	private String ename;
	
	public Emp() {}

	public Emp(String ename) {
		this.ename = ename;
	}

	public Emp(Long empno, String ename) {
		this.empno = empno;
		this.ename = ename;
	}

	public Long getEmpno() {
		return empno;
	}

	public void setEmpno(Long empno) {
		this.empno = empno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	@Override
	public String toString() {
		return "[empno= " + empno + ", ename= " + ename + "]";
	}
}
