package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jdbc3Application {

	public static void main(String[] args) {
		SpringApplication.run(Jdbc3Application.class, args);
	}
}
