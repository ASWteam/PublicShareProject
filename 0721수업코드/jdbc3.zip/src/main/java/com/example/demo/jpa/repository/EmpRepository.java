package com.example.demo.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.jpa.domain.Emp;

public interface EmpRepository extends JpaRepository<Emp, Long> {

}
