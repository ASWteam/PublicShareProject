package jdbc;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmpDao {
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	List getNames() {
		String sql = "select * from emp";
		return jdbcTemplate.queryForList(sql);
	}
}
