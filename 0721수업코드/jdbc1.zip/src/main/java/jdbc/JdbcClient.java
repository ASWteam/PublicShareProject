package jdbc;

import org.springframework.context.support.GenericXmlApplicationContext;

public class JdbcClient {

	public static void main(String[] args) {
		GenericXmlApplicationContext context = new GenericXmlApplicationContext();
		context.load("app-jdbc.xml");
		context.refresh();
		
		EmpDao e = (EmpDao) context.getBean("EmpDao");
		System.out.println(e.getNames());
		context.close();
	}
}
