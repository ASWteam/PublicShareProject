package com.javatpoint;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test implements CommandLineRunner {
	
	@Autowired
	EmployeeDao dao;
	
	public static void main(String[] args) {
		SpringApplication.run(Test.class, args);
		
	}

	@Override
	public void run(String... arg0) throws Exception {
		
		List<Employee> employees = dao.findAll();
		int i = 1;
		for (Employee e : employees) {
			System.out.print(i++ + ". ");
			System.out.println(e);
		}
		System.out.println("----------selectAll----------");

		dao.saveEmployee(new Employee(111,"sonoo",15000));
		employees = dao.findAll();
		i = 1;
		for (Employee e : employees) {
			System.out.print(i++ + ". ");
			System.out.println(e);
		}
		System.out.println("----------insert----------");
		
		Employee employee = dao.findOne(new Employee(1));
		System.out.println(employee);
		System.out.println("----------selectById----------");
		
	}
}
