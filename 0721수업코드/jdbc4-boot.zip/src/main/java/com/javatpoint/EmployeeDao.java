package com.javatpoint;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDao {
	private JdbcTemplate jdbcTemplate;
	RowMapper<Employee> employeeRowMapper;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Autowired
	public void setEmployeeRowMapper(RowMapper<Employee> employeeRowMapper) {
		this.employeeRowMapper = employeeRowMapper;
	}

	public int saveEmployee(Employee e) {
		String query = 
			"insert into employee values('"+e.getId()+"','"+e.getName()+"','"+e.getSalary()+"')";
		return jdbcTemplate.update(query);
	}
	
	public int updateEmployee(Employee e) {
		String query = "update employee set name='"+e.getName()+"',salary='"+e.getSalary()+"'where id='"+e.getId()+"'";
		return jdbcTemplate.update(query);
	}
	
	public int deleteEmployee(Employee e) {
		String query = "delete from employee where id='"+e.getId()+"'";
		return jdbcTemplate.update(query);
	}
	
	public List<Employee> findAll() {
		String query = "select * from employee";
		List<Employee> employees = jdbcTemplate.query(query, employeeRowMapper);
		return employees;
	}
	
	public Employee findOne(Employee e) {
		String query = "select * from employee where id= '"+e.getId()+"'";
		Employee employee = jdbcTemplate.queryForObject(query, employeeRowMapper);
		return employee;
	}
}
