package com.example.demo.ioc;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

@Component
public class CoffeeManager {
	
	private CoffeeMaker maker;

	@Resource(name="phillips")
	public void setMaker(CoffeeMaker maker) {
		this.maker = maker;
	}

	public void order() {
		this.maker.coffeeExtract();
	}
}
