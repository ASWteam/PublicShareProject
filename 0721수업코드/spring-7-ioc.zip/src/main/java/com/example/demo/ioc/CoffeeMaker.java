package com.example.demo.ioc;

public interface CoffeeMaker {
	public void coffeeExtract();
}
