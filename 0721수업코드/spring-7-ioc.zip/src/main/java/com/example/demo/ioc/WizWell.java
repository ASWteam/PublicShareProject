package com.example.demo.ioc;

import org.springframework.stereotype.Component;

@Component
public class WizWell implements CoffeeMaker{

	@Override
	public void coffeeExtract() {
		System.out.println("WizWell make coffee.");
	}

}
