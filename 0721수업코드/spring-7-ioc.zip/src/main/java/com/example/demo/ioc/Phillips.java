package com.example.demo.ioc;

import org.springframework.stereotype.Component;

@Component
public class Phillips  implements CoffeeMaker{

	@Override
	public void coffeeExtract() {
		System.out.println("Phillips make coffee.");
	}


}
