package com.example.demo.ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CoffeeMakerMain {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("coffee-config-anno.xml");
		CoffeeManager coffeeManager = (CoffeeManager) context.getBean("coffeeManager");
		
		coffeeManager.order();
	}
}
